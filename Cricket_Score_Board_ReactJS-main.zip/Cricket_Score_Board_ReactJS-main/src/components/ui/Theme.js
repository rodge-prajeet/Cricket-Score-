const { createTheme } = require('@material-ui/core')

export const theme = createTheme({
  palette: {
    common: {},
  },
  typography: {},
})
